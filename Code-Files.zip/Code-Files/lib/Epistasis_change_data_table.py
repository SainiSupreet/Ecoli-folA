from bio_functions import *

parent_file = '../Epistasis/Detailed data - epistasis change/Complete epistasis data - All.csv'

parent_df = pd.read_csv(parent_file)

data_table = {
    'Mutation A':[],
    'Mutation A locus':[],
    'Mutation B':[],
    'Mutation B locus':[],
    }

for i in range(1,10):
    data_table[f'X locus {i}'] = []

count = 0
total = len(detailed_mutation_pair)

for mut_pair in detailed_mutation_pair:

    mut_A = mut_pair[0]
    mut_B = mut_pair[1]
    
    reduced_df = parent_df[parent_df['mut A bg'] == mut_A[0]]
    reduced_df = reduced_df[reduced_df['mut A result'] == mut_A[1]]
    reduced_df = reduced_df[reduced_df['mut A locus'] == mut_A[2]+1]
    reduced_df = reduced_df[reduced_df['mut B bg'] == mut_B[0]]
    reduced_df = reduced_df[reduced_df['mut B result'] == mut_B[1]]
    reduced_df = reduced_df[reduced_df['mut B locus'] == mut_B[2]+1]

    data_table['Mutation A'].append(f'{mut_A[0]} -> {mut_A[1]}')
    data_table['Mutation A locus'].append(mut_A[2]+1)
    data_table['Mutation B'].append(f'{mut_B[0]} -> {mut_B[1]}')
    data_table['Mutation B locus'].append(mut_B[2]+1)

    for locus in range(1,10):
        
        locus_df = reduced_df[reduced_df['mut X locus'] == locus]

        total_count = sum(locus_df['Count'].values)
        change_count = sum(locus_df[locus_df['epistasis on bg'] != locus_df['epistasis on mut']]\
                           ['Count'].values)

        try:
            data_table[f'X locus {locus}'].append(change_count/total_count)
        except ZeroDivisionError:
            data_table[f'X locus {locus}'].append(None)

    count += 1

    if count in [total//(100/i) for i in range(5,101,5)]:
        print(f'{round(100*count/total,0)}% mutations analysed')

data_df = pd.DataFrame(data_table)
data_df.to_csv('../Epistasis/Detailed data - epistasis change/Complete table - fractions.csv',index = False)

## Functional variants
parent_file = '../Epistasis/Detailed data - epistasis change/Complete epistasis data - Functional.csv'

parent_df = pd.read_csv(parent_file)

data_table = {
    'Mutation A':[],
    'Mutation A locus':[],
    'Mutation B':[],
    'Mutation B locus':[],
    }

for i in range(1,10):
    data_table[f'X locus {i}'] = []

count = 0
total = len(detailed_mutation_pair)

for mut_pair in detailed_mutation_pair:

    mut_A = mut_pair[0]
    mut_B = mut_pair[1]
    
    reduced_df = parent_df[parent_df['mut A bg'] == mut_A[0]]
    reduced_df = reduced_df[reduced_df['mut A result'] == mut_A[1]]
    reduced_df = reduced_df[reduced_df['mut A locus'] == mut_A[2]+1]
    
    reduced_df = reduced_df[reduced_df['mut B bg'] == mut_B[0]]
    reduced_df = reduced_df[reduced_df['mut B result'] == mut_B[1]]
    reduced_df = reduced_df[reduced_df['mut B locus'] == mut_B[2]+1]

    data_table['Mutation A'].append(f'{mut_A[0]} -> {mut_A[1]}')
    data_table['Mutation A locus'].append(mut_A[2]+1)
    data_table['Mutation B'].append(f'{mut_B[0]} -> {mut_B[1]}')
    data_table['Mutation B locus'].append(mut_B[2]+1)

    for locus in range(1,10):
        
        locus_df = reduced_df[reduced_df['mut X locus'] == locus]

        total_count = sum(locus_df['Count'].values)
        change_count = sum(locus_df[locus_df['epistasis on bg'] != locus_df['epistasis on mut']]\
                           ['Count'].values)

        try:
            data_table[f'X locus {locus}'].append(change_count/total_count)
        except ZeroDivisionError:
            data_table[f'X locus {locus}'].append(None)

    count += 1

    if count in [total//(100/i) for i in range(5,101,5)]:
        print(f'{round(100*count/total,0)}% mutations analysed')

data_df = pd.DataFrame(data_table)
data_df.to_csv('../Epistasis/Detailed data - epistasis change/Functional table - fractions.csv',index = False)

## Non Functional variants
parent_file = '../Epistasis/Detailed data - epistasis change/Complete epistasis data - Non Functional.csv'

parent_df = pd.read_csv(parent_file)

data_table = {
    'Mutation A':[],
    'Mutation A locus':[],
    'Mutation B':[],
    'Mutation B locus':[],
    }

for i in range(1,10):
    data_table[f'X locus {i}'] = []

count = 0
total = len(detailed_mutation_pair)

for mut_pair in detailed_mutation_pair:

    mut_A = mut_pair[0]
    mut_B = mut_pair[1]
    
    reduced_df = parent_df[parent_df['mut A bg'] == mut_A[0]]
    reduced_df = reduced_df[reduced_df['mut A result'] == mut_A[1]]
    reduced_df = reduced_df[reduced_df['mut A locus'] == mut_A[2]+1]
    
    reduced_df = reduced_df[reduced_df['mut B bg'] == mut_B[0]]
    reduced_df = reduced_df[reduced_df['mut B result'] == mut_B[1]]
    reduced_df = reduced_df[reduced_df['mut B locus'] == mut_B[2]+1]

    data_table['Mutation A'].append(f'{mut_A[0]} -> {mut_A[1]}')
    data_table['Mutation A locus'].append(mut_A[2]+1)
    data_table['Mutation B'].append(f'{mut_B[0]} -> {mut_B[1]}')
    data_table['Mutation B locus'].append(mut_B[2]+1)

    for locus in range(1,10):
        
        locus_df = reduced_df[reduced_df['mut X locus'] == locus]

        total_count = sum(locus_df['Count'].values)
        change_count = sum(locus_df[locus_df['epistasis on bg'] != locus_df['epistasis on mut']]\
                           ['Count'].values)

        try:
            data_table[f'X locus {locus}'].append(change_count/total_count)
        except ZeroDivisionError:
            data_table[f'X locus {locus}'].append(None)

    count += 1

    if count in [total//(100/i) for i in range(5,101,5)]:
        print(f'{round(100*count/total,0)}% mutations analysed')

data_df = pd.DataFrame(data_table)
data_df.to_csv('../Epistasis/Detailed data - epistasis change/Non Functional table - fractions.csv',index = False)

## Functional variants - specific epistasis change
parent_file = '../Epistasis/Detailed data - epistasis change/Complete epistasis data - Functional.csv'

epistasis = ['Positive','Negative','Reciprocal Sign','Single Sign','Other Sign','No Epistasis']

epistasis_change_pairs = []
for i in epistasis:
    for j in epistasis:
        epistasis_change_pairs.append((i,j))

parent_df = pd.read_csv(parent_file)

for epi_pair in epistasis_change_pairs:

    print(epi_pair)

    data_table = {
        'Mutation A':[],
        'Mutation A locus':[],
        'Mutation B':[],
        'Mutation B locus':[],
        }

    daughter_df = parent_df[parent_df['epistasis on bg'] == epi_pair[0]]

    for i in range(1,10):
        data_table[f'X locus {i}'] = []

    count = 0
    total = len(detailed_mutation_pair)

    for mut_pair in detailed_mutation_pair:

        mut_A = mut_pair[0]
        mut_B = mut_pair[1]
        
        reduced_df = daughter_df[daughter_df['mut A bg'] == mut_A[0]]
        reduced_df = reduced_df[reduced_df['mut A result'] == mut_A[1]]
        reduced_df = reduced_df[reduced_df['mut A locus'] == mut_A[2]+1]
        
        reduced_df = reduced_df[reduced_df['mut B bg'] == mut_B[0]]
        reduced_df = reduced_df[reduced_df['mut B result'] == mut_B[1]]
        reduced_df = reduced_df[reduced_df['mut B locus'] == mut_B[2]+1]

        data_table['Mutation A'].append(f'{mut_A[0]} -> {mut_A[1]}')
        data_table['Mutation A locus'].append(mut_A[2]+1)
        data_table['Mutation B'].append(f'{mut_B[0]} -> {mut_B[1]}')
        data_table['Mutation B locus'].append(mut_B[2]+1)

        for locus in range(1,10):
            
            locus_df = reduced_df[reduced_df['mut X locus'] == locus]

            total_count = sum(locus_df['Count'].values)
            change_count = sum(locus_df[locus_df['epistasis on mut'] == epi_pair[1]]['Count'].values)

            try:
                data_table[f'X locus {locus}'].append(change_count/total_count)
            except ZeroDivisionError:
                data_table[f'X locus {locus}'].append(None)

        count += 1

        if count in [total//(100/i) for i in range(5,101,5)]:
            print(f'{round(100*count/total,0)}% mutations analysed')

    data_df = pd.DataFrame(data_table)
    data_df.to_csv(f'../Epistasis/Detailed data - epistasis change/Epistasis change fraction/Functional {epi_pair[0]} -> {epi_pair[1]} - fractions.csv',index = False)

## Non Functional variants - specific epistasis change
parent_file = '../Epistasis/Detailed data - epistasis change/Complete epistasis data - Non Functional.csv'

epistasis = ['Positive','Negative','Reciprocal Sign','Single Sign','Other Sign','No Epistasis']

epistasis_change_pairs = []
for i in epistasis:
    for j in epistasis:
        epistasis_change_pairs.append((i,j))

parent_df = pd.read_csv(parent_file)

for epi_pair in epistasis_change_pairs:

    print(epi_pair)

    data_table = {
        'Mutation A':[],
        'Mutation A locus':[],
        'Mutation B':[],
        'Mutation B locus':[],
        }

    daughter_df = parent_df[parent_df['epistasis on bg'] == epi_pair[0]]

    for i in range(1,10):
        data_table[f'X locus {i}'] = []

    count = 0
    total = len(detailed_mutation_pair)

    for mut_pair in detailed_mutation_pair:

        mut_A = mut_pair[0]
        mut_B = mut_pair[1]
        
        reduced_df = daughter_df[daughter_df['mut A bg'] == mut_A[0]]
        reduced_df = reduced_df[reduced_df['mut A result'] == mut_A[1]]
        reduced_df = reduced_df[reduced_df['mut A locus'] == mut_A[2]+1]
        
        reduced_df = reduced_df[reduced_df['mut B bg'] == mut_B[0]]
        reduced_df = reduced_df[reduced_df['mut B result'] == mut_B[1]]
        reduced_df = reduced_df[reduced_df['mut B locus'] == mut_B[2]+1]


        data_table['Mutation A'].append(f'{mut_A[0]} -> {mut_A[1]}')
        data_table['Mutation A locus'].append(mut_A[2]+1)
        data_table['Mutation B'].append(f'{mut_B[0]} -> {mut_B[1]}')
        data_table['Mutation B locus'].append(mut_B[2]+1)

        for locus in range(1,10):
            
            locus_df = reduced_df[reduced_df['mut X locus'] == locus]

            total_count = sum(locus_df['Count'].values)
            change_count = sum(locus_df[locus_df['epistasis on mut'] == epi_pair[1]]['Count'].values)

            try:
                data_table[f'X locus {locus}'].append(change_count/total_count)
            except ZeroDivisionError:
                data_table[f'X locus {locus}'].append(None)

        count += 1

        if count in [total//(100/i) for i in range(5,101,5)]:
            print(f'{round(100*count/total,0)}% mutations analysed')

    data_df = pd.DataFrame(data_table)
    data_df.to_csv(f'../Epistasis/Detailed data - epistasis change/Epistasis change fraction/Non Functional {epi_pair[0]} -> {epi_pair[1]} - fractions.csv',index = False)

## Functional variants - specific epistasis
parent_file = '../Epistasis/Detailed data - epistasis change/Complete epistasis data - Functional.csv'

epistasis = ['Positive','Negative','Reciprocal Sign','Single Sign','Other Sign','No Epistasis']

parent_df = pd.read_csv(parent_file)

data_table = {
    'Mutation A':[],
    'Mutation A locus':[],
    'Mutation B':[],
    'Mutation B locus':[],
    }

for epi in epistasis:

    data_table[epi] = []

count = 0
total = len(detailed_mutation_pair)

for mut_pair in detailed_mutation_pair:

    mut_A = mut_pair[0]
    mut_B = mut_pair[1]
    
    reduced_df = parent_df[parent_df['mut A bg'] == mut_A[0]]
    reduced_df = reduced_df[reduced_df['mut A result'] == mut_A[1]]
    reduced_df = reduced_df[reduced_df['mut A locus'] == mut_A[2]+1]
    
    reduced_df = reduced_df[reduced_df['mut B bg'] == mut_B[0]]
    reduced_df = reduced_df[reduced_df['mut B result'] == mut_B[1]]
    reduced_df = reduced_df[reduced_df['mut B locus'] == mut_B[2]+1]

    data_table['Mutation A'].append(f'{mut_A[0]} -> {mut_A[1]}')
    data_table['Mutation A locus'].append(mut_A[2]+1)
    data_table['Mutation B'].append(f'{mut_B[0]} -> {mut_B[1]}')
    data_table['Mutation B locus'].append(mut_B[2]+1)

    for epi in epistasis:
            
        total_count = sum(reduced_df['Count'].values)
        change_count = sum(reduced_df[reduced_df['epistasis on bg'] == epi]['Count'].values)

        data_table[epi].append(change_count/total_count)

    count += 1

    if count in [total//(100/i) for i in range(5,101,5)]:
        print(f'{round(100*count/total,0)}% mutations analysed')

data_df = pd.DataFrame(data_table)
data_df.to_csv(f'../Epistasis/Detailed data - epistasis change/Functional Epistasis - fractions.csv',index = False)

## Non Functional variants - specific epistasis
parent_file = '../Epistasis/Detailed data - epistasis change/Complete epistasis data - Non Functional.csv'

epistasis = ['Positive','Negative','Reciprocal Sign','Single Sign','Other Sign','No Epistasis']

parent_df = pd.read_csv(parent_file)

data_table = {
    'Mutation A':[],
    'Mutation A locus':[],
    'Mutation B':[],
    'Mutation B locus':[],
    }

for epi in epistasis:

    data_table[epi] = []

count = 0
total = len(detailed_mutation_pair)

for mut_pair in detailed_mutation_pair:

    mut_A = mut_pair[0]
    mut_B = mut_pair[1]
    
    reduced_df = parent_df[parent_df['mut A bg'] == mut_A[0]]
    reduced_df = reduced_df[reduced_df['mut A result'] == mut_A[1]]
    reduced_df = reduced_df[reduced_df['mut A locus'] == mut_A[2]+1]
    
    reduced_df = reduced_df[reduced_df['mut B bg'] == mut_B[0]]
    reduced_df = reduced_df[reduced_df['mut B result'] == mut_B[1]]
    reduced_df = reduced_df[reduced_df['mut B locus'] == mut_B[2]+1]

    data_table['Mutation A'].append(f'{mut_A[0]} -> {mut_A[1]}')
    data_table['Mutation A locus'].append(mut_A[2]+1)
    data_table['Mutation B'].append(f'{mut_B[0]} -> {mut_B[1]}')
    data_table['Mutation B locus'].append(mut_B[2]+1)

    for epi in epistasis:
            
        total_count = sum(reduced_df['Count'].values)
        change_count = sum(reduced_df[reduced_df['epistasis on bg'] == epi]['Count'].values)

        data_table[epi].append(change_count/total_count)

    count += 1

    if count in [total//(100/i) for i in range(5,101,5)]:
        print(f'{round(100*count/total,0)}% mutations analysed')

data_df = pd.DataFrame(data_table)
data_df.to_csv(f'../Epistasis/Detailed data - epistasis change/Non Functional Epistasis - fractions.csv',index = False)

# MWU test tables:

tables = ['../Epistasis/Detailed data - epistasis change/Functional table - fractions.csv',
          '../Epistasis/Detailed data - epistasis change/Non Functional table - fractions.csv']

epistasis = ['Positive','Negative','Reciprocal Sign','Single Sign','Other Sign','No Epistasis']
column = [f'X locus {i}' for i in range(1,10)]

for table in tables:

    data = {None:[]}
    for k in column:
        data[k] = []
        
    df = pd.read_csv(table)

    for i in range(len(column)):
        
        data[None].append(column[i])
        
        for j in range(i+1):
            data[column[j]].append(round(stats.mannwhitneyu(df[column[i]]\
                                                      [df[column[i]].notna() == True].values,
                                                      df[column[j]]\
                                                      [df[column[j]].notna() == True].values).pvalue,10))

        for l in range(i+1,len(column)):
            data[column[l]].append(None)

    ans_df = pd.DataFrame(data)
    ans_df.to_csv(table[:-13] + 'MWU test pvalues.csv',index = False)
            
