from bio_functions import *

path = '../Epistasis/'

# Find 1 Hamming distance neighbours with synonymous mutations
synonymous_neighbours = {}

for i in codon_table.values():
    for j in i:
        neighbours = []
        synonymous_neighbours[j] = []
        for k in i:
            if H_distance(j,k)==1:
                synonymous_neighbours[j].append(k)


data = {
    'Mutation A base':[],
    'Mutation A result':[],
    'Mutation A locus':[],
    
    'Mutation B base':[],
    'Mutation B result':[],
    'Mutation B locus':[],
    
    'Epistasis at bg':[],
    
    'Unmutated codon':[],
    'Syn mutation X locus':[],
    'Mutated codon':[],
    
    'Epistasis at mut':[],
    
    'Count':[]}

series = {}

errors = set()
count = 0
total_variants = 4**9

print('Functional variants')
# Functional variants
for variant in get_variants(9):
    count += 1
    
    try:
        if fitness_data[variant] <= threshold:

            if count in [total_variants//(100/i) for i in range(5,101,5)]:
                print(f'{round(100*count/total_variants,0)}% variants analysed')

            continue
        
    except KeyError:
        continue

    for mut_pair in generate_mutations(2):
        mut_A = mut_pair[0]
        mut_B = mut_pair[1]

        # Find unmutated codons
        unmutated_codons = [1,2,3]
        uc_copy = unmutated_codons.copy()
        for uc in uc_copy:
            if mut_A[1] in range((uc-1)*3,uc*3) or mut_B[1] in range((uc-1)*3,uc*3):
                unmutated_codons.remove(uc)

        if not (mutation_feasibility(variant,mut_A) and \
                mutation_feasibility(variant,mut_B)):
            continue

        try:
            mut_bA = get_mutant(variant,mut_A)
            mut_bB = get_mutant(variant,mut_B)

            be_nature = check_epistasis_nature(variant,mut_pair)['Nature']
            
        except KeyError:
            continue

        for uc in unmutated_codons:
            codon = variant[(uc-1)*3:uc*3]
            syn_codons = synonymous_neighbours[codon]

            for syn_c in syn_codons:
                
                try:
                    m = variant[:(uc-1)*3] + syn_c + variant[uc*3:]
                    mut_X_loci = find_mutations_loci(variant,m)
                    assert len(mut_X_loci) == 1

                    me_nature = check_epistasis_nature(m,mut_pair)['Nature']
                    
                except KeyError:
                    continue

                sub_series = (
                    
                    variant[mut_A[1]],
                    mut_A[0],
                    mut_A[1]+1,

                    variant[mut_B[1]],
                    mut_B[0],
                    mut_B[1]+1,

                    be_nature,

                    codon,
                    mut_X_loci[0] + 1,
                    syn_c,

                    me_nature
                    )

                try:
                    series[sub_series] += 1
                except KeyError:
                    series[sub_series] = 1

    if count in [total_variants//(100/i) for i in range(5,101,5)]:
        print(f'{round(100*count/total_variants,0)}% variants analysed')

data_keys = list(data.keys())
for key in series.keys():
    for i in range(len(key)):
        data[data_keys[i]].append(key[i])
    data['Count'].append(series[key])

df = pd.DataFrame(data)
df.to_csv(f'{path}Epistasis change by synonymous mutations - Functional.csv',index = False)

print('Non functional variants')

# Non Functional variants

data = {
    'Mutation A base':[],
    'Mutation A result':[],
    'Mutation A locus':[],
    
    'Mutation B base':[],
    'Mutation B result':[],
    'Mutation B locus':[],
    
    'Epistasis at bg':[],
    
    'Unmutated codon':[],
    'Syn mutation X locus':[],
    'Mutated codon':[],
    
    'Epistasis at mut':[],
    
    'Count':[]}

series = {}

errors = set()
count = 0
total_variants = 4**9

for variant in get_variants(9):
    count += 1
    
    try:
        if fitness_data[variant] >= threshold:

            if count in [total_variants//(100/i) for i in range(5,101,5)]:
                print(f'{round(100*count/total_variants,0)}% variants analysed')

            continue
        
    except KeyError:
        continue

    for mut_pair in generate_mutations(2):
        mut_A = mut_pair[0]
        mut_B = mut_pair[1]

        # Find unmutated codons
        unmutated_codons = [1,2,3]
        uc_copy = unmutated_codons.copy()
        for uc in uc_copy:
            if mut_A[1] in range((uc-1)*3,uc*3) or mut_B[1] in range((uc-1)*3,uc*3):
                unmutated_codons.remove(uc)

        if not (mutation_feasibility(variant,mut_A) and \
                mutation_feasibility(variant,mut_B)):
            continue

        try:
            mut_bA = get_mutant(variant,mut_A)
            mut_bB = get_mutant(variant,mut_B)

            be_nature = check_epistasis_nature(variant,mut_pair)['Nature']
            
        except KeyError:
            continue

        for uc in unmutated_codons:
            codon = variant[(uc-1)*3:uc*3]
            syn_codons = synonymous_neighbours[codon]

            for syn_c in syn_codons:
                
                try:
                    m = variant[:(uc-1)*3] + syn_c + variant[uc*3:]
                    mut_X_loci = find_mutations_loci(variant,m)
                    assert len(mut_X_loci) == 1

                    me_nature = check_epistasis_nature(m,mut_pair)['Nature']
                    
                except KeyError:
                    continue

                sub_series = (
                    
                    variant[mut_A[1]],
                    mut_A[0],
                    mut_A[1]+1,

                    variant[mut_B[1]],
                    mut_B[0],
                    mut_B[1]+1,

                    be_nature,

                    codon,
                    mut_X_loci[0] + 1,
                    syn_c,

                    me_nature
                    )

                try:
                    series[sub_series] += 1
                except KeyError:
                    series[sub_series] = 1

    if count in [total_variants//(100/i) for i in range(5,101,5)]:
        print(f'{round(100*count/total_variants,0)}% variants analysed')

data_keys = list(data.keys())
for key in series.keys():
    for i in range(len(key)):
        data[data_keys[i]].append(key[i])
    data['Count'].append(series[key])

df = pd.DataFrame(data)
df.to_csv(f'{path}Epistasis change by synonymous mutations - Non Functional.csv',index = False)

print('All variants')
# All variants

data = {
    'Mutation A base':[],
    'Mutation A result':[],
    'Mutation A locus':[],
    
    'Mutation B base':[],
    'Mutation B result':[],
    'Mutation B locus':[],
    
    'Epistasis at bg':[],
    
    'Unmutated codon':[],
    'Syn mutation X locus':[],
    'Mutated codon':[],
    
    'Epistasis at mut':[],
    
    'Count':[]}

series = {}

errors = set()
count = 0
total_variants = 4**9

for variant in get_variants(9):
    count += 1

    for mut_pair in generate_mutations(2):
        mut_A = mut_pair[0]
        mut_B = mut_pair[1]

        # Find unmutated codons
        unmutated_codons = [1,2,3]
        uc_copy = unmutated_codons.copy()
        for uc in uc_copy:
            if mut_A[1] in range((uc-1)*3,uc*3) or mut_B[1] in range((uc-1)*3,uc*3):
                unmutated_codons.remove(uc)

        if not (mutation_feasibility(variant,mut_A) and \
                mutation_feasibility(variant,mut_B)):
            continue

        try:
            mut_bA = get_mutant(variant,mut_A)
            mut_bB = get_mutant(variant,mut_B)

            be_nature = check_epistasis_nature(variant,mut_pair)['Nature']
            
        except KeyError:
            continue

        for uc in unmutated_codons:
            codon = variant[(uc-1)*3:uc*3]
            syn_codons = synonymous_neighbours[codon]

            for syn_c in syn_codons:
                
                try:
                    m = variant[:(uc-1)*3] + syn_c + variant[uc*3:]
                    mut_X_loci = find_mutations_loci(variant,m)
                    assert len(mut_X_loci) == 1

                    me_nature = check_epistasis_nature(m,mut_pair)['Nature']
                    
                except KeyError:
                    continue

                sub_series = (
                    
                    variant[mut_A[1]],
                    mut_A[0],
                    mut_A[1]+1,

                    variant[mut_B[1]],
                    mut_B[0],
                    mut_B[1]+1,

                    be_nature,

                    codon,
                    mut_X_loci[0] + 1,
                    syn_c,

                    me_nature
                    )

                try:
                    series[sub_series] += 1
                except KeyError:
                    series[sub_series] = 1

    if count in [total_variants//(100/i) for i in range(5,101,5)]:
        print(f'{round(100*count/total_variants,0)}% variants analysed')

data_keys = list(data.keys())
for key in series.keys():
    for i in range(len(key)):
        data[data_keys[i]].append(key[i])
    data['Count'].append(series[key])

df = pd.DataFrame(data)
df.to_csv(f'{path}Epistasis change by synonymous mutations - All.csv',index = False)

# Arranging data - Functional
df = pd.read_csv(f'{path}Epistasis change by synonymous mutations - Functional.csv')

data = {
    'X locus':[],
    'Change':[],
    'No change':[]
    }

for locus in range(1,10):
    data['X locus'].append(locus)

    reduced_df = df[df['Syn mutation X locus'] == locus]

    change_count = sum(reduced_df[reduced_df['Epistasis at bg'] != reduced_df['Epistasis at mut']]\
                       ['Count'].values)
    no_change_count = sum(reduced_df[reduced_df['Epistasis at bg'] == reduced_df['Epistasis at mut']]\
                          ['Count'].values)

    data['Change'].append(change_count)
    data['No change'].append(no_change_count)

table_df = pd.DataFrame(data)
table_df.to_csv(f'{path}Summary table of epistasis change by synonymous mutation - Functional.csv',index = False)

# Arranging data - Non Functional
df = pd.read_csv(f'{path}Epistasis change by synonymous mutations - Non Functional.csv')

data = {
    'X locus':[],
    'Change':[],
    'No change':[]
    }

for locus in range(1,10):
    data['X locus'].append(locus)

    reduced_df = df[df['Syn mutation X locus'] == locus]

    change_count = sum(reduced_df[reduced_df['Epistasis at bg'] != reduced_df['Epistasis at mut']]\
                       ['Count'].values)
    no_change_count = sum(reduced_df[reduced_df['Epistasis at bg'] == reduced_df['Epistasis at mut']]\
                          ['Count'].values)

    data['Change'].append(change_count)
    data['No change'].append(no_change_count)

table_df = pd.DataFrame(data)
table_df.to_csv(f'{path}Summary table of epistasis change by synonymous mutation - Non Functional.csv',index = False)

# Arranging data - All
df = pd.read_csv(f'{path}Epistasis change by synonymous mutations - All.csv')

data = {
    'X locus':[],
    'Change':[],
    'No change':[]
    }

for locus in range(1,10):
    data['X locus'].append(locus)

    reduced_df = df[df['Syn mutation X locus'] == locus]

    change_count = sum(reduced_df[reduced_df['Epistasis at bg'] != reduced_df['Epistasis at mut']]\
                       ['Count'].values)
    no_change_count = sum(reduced_df[reduced_df['Epistasis at bg'] == reduced_df['Epistasis at mut']]\
                          ['Count'].values)

    data['Change'].append(change_count)
    data['No change'].append(no_change_count)

table_df = pd.DataFrame(data)
table_df.to_csv(f'{path}Summary table of epistasis change by synonymous mutation - All.csv',index = False)

